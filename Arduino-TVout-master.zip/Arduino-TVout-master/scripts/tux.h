#include <avr/pgmspace.h>
#ifndef tux_H
#define tux_H
extern const unsigned char tux[];
#endif
