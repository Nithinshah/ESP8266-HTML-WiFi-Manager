#include <avr/pgmspace.h>
#ifndef SKULL_H
#define SKULL_H

extern const unsigned char skull[];
#endif
